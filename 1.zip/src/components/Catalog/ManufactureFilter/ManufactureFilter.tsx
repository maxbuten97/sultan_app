import React, { useState } from "react";
import s from "./ManufactureFilter.module.css";
import data from "../../../data.json";
import { IProduct } from "../../../shared/interfaces/ProductInterface";
import { CareCategoriesEnum } from "../../../shared/enums/CareCategoriesEnum";
import { ICareCategory } from "../../../shared/interfaces/CareCategoryInterface";
import ManufactureFilterCheckbox from "./ManufactureFilterCheckbox/ManufactureFilterCheckbox";
const searchSVG: string = require("../../../image/search.svg").default;

/** Полный список продуктов */

const ManufactureFilter = (props: {
  manufactures: string[];
  changeManufactureFilter: (manufactureFilters: string[]) => void;
}) => {
  const [manufactureFilter, setManufactureFilter] = useState<string[]>([]);

  function selectManufactureFilter(manufacture: string) {
    let newManufactures = [];
    if (manufactureFilter.includes(manufacture)) {
      newManufactures = manufactureFilter.filter((m) => m !== manufacture);
    } else {
      newManufactures = manufactureFilter;
      newManufactures.push(manufacture);
    }

    setManufactureFilter(newManufactures);
    props.changeManufactureFilter(newManufactures);
  }

  return (
    <div className={s.manufacturer__filter}>
      <div className={s.manufacturer__title}>Производитель</div>
      <div className={s.search}>
        <div className={s.input__wrapper}>
          <input
            className={s.search__input}
            type="text"
            placeholder="Поиск..."
          />
        </div>
        <div className={s.image__wrapper}>
          <img className={s.search__image} src={searchSVG} alt="search" />
        </div>
      </div>
      <div className={s.checkbox__block}>
        {props.manufactures.map((manufacture, index) => {
          return (
            <ManufactureFilterCheckbox
              manufacture={manufacture}
              selectManufactureFilter={selectManufactureFilter}
              key={index}
            />
          );
        })}
      </div>
      <div className={s.view}>Показать все</div>
    </div>
  );
};

export default ManufactureFilter;
