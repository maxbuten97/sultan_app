import React, { useState } from 'react';
import s from './Catalog.module.css';
import BreadCrumbs from './BreadCrumbs/BreadCrumbs';
import CatalogCategories from './CatalogCategories/CatalogCategories';
import Content from './Cоntent/Content';
import CareCategory from './Cоntent/CareCategory/CareCategory';

const Catalog = () => {
    const [selectedCareCategory, setSelectedCareCategory] = useState<string>('')


    return (
        <div className={s.catalog}>
            <BreadCrumbs />
            <CatalogCategories selectedCareCategory={selectedCareCategory} setSelectedCareCategory={setSelectedCareCategory}/>
            <Content selectedCareCategory={selectedCareCategory} setSelectedCareCategory={setSelectedCareCategory}/>
        </div>
    );
};

export default Catalog;