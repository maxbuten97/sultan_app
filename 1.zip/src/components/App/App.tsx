import React from "react";
import s from "./App.module.css";
import Header from "../Header/Header";
import Footer from "../Footer/Footer";
import Nav from "../Nav/Nav";
import Main from "../Main/Main";
import CardProduct from "../CardProduct/CardProduct";
import Catalog from "../Catalog/Catalog";
import Basket from "../Basket/Basket";
import Ordering from "../Ordering/Ordering";
import { BrowserRouter, Routes, Route } from "react-router-dom";

function App() {
  return (
    <BrowserRouter>
      <div className="App">
        <div className={s.wrapper}>
          <div className={s.content}>
            <Header />
            <Nav />
            <Routes>
              <Route path="/" element={<Main />} />
              <Route path="/card-product/:id" element={<CardProduct />} />
              <Route path="/catalog" element={<Catalog />} />
              <Route path="/basket" element={<Basket />} />
              <Route path="/ordering" element={<Ordering />} />
            </Routes>
          </div>
          <Footer />
        </div>
      </div>
    </BrowserRouter>
  );
}

export default App;
