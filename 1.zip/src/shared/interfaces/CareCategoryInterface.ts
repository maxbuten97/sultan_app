
export interface ICareCategory {
    category: string;
    name: string;
}