import React, { useState } from 'react';
import s from './Catalog.module.css';
import BreadCrumbs from './BreadCrumbs/BreadCrumbs';
import CatalogCategories from './CatalogCategories/CatalogCategories';
import Content from './Cоntent/Content';
import { IProduct } from '../../shared/interfaces/ProductInterface';
import { ICareCategory } from '../../shared/interfaces/CareCategoryInterface';

const Catalog = (props: {
    storage: IProduct[];
    careCategories: ICareCategory[];
    deleteProduct: (product:IProduct) => void;
}) => {
    const [selectedCareCategory, setSelectedCareCategory] = useState<string>('')


    return (
        <div className={s.catalog}>
            <BreadCrumbs />
            <CatalogCategories selectedCareCategory={selectedCareCategory} setSelectedCareCategory={setSelectedCareCategory} careCategories={props.careCategories}/>
            <Content selectedCareCategory={selectedCareCategory} setSelectedCareCategory={setSelectedCareCategory} storage={props.storage} careCategories={props.careCategories} deleteProduct={props.deleteProduct}/>
        </div>
    );
};

export default Catalog;