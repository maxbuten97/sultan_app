export enum CareCategoriesEnum {
    Body = 'Body',
    Hands = 'Hands',
    Legs = 'Legs',
    Face = 'Face',
    Hair = 'Hair',
    Sun = 'Sun',
    Shave = 'Shave',
    GiftBox = 'GiftBox',
    HygieneProducts = 'HygieneProducts',
    OralHygiene = 'OralHygiene',
    PaperProducts = 'PaperProducts'
}